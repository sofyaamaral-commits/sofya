# Agrinho Paraná 2026
Abra index.html no navegador.